from pathlib import Path
import ctypes,ctypes.util,struct,json,hashlib,lzma

class Reader:
    def __init__(self,b,e='>'):self.b,self.p,self.e=b,0,e
    def take(self,n):
        assert 0<=n<=len(self.b)-self.p,(self.p,n,len(self.b))
        x=self.b[self.p:self.p+n];self.p+=n;return x
    def fmt(self,f):return struct.unpack(self.e+f,self.take(struct.calcsize(self.e+f)))
    def num(self,f):return self.fmt(f)[0]
    def z(self):
        q=self.b.index(0,self.p);x=self.take(q-self.p);self.take(1);return x.decode()
    def align(self,n=4):self.p=(self.p+n-1)//n*n

lib=ctypes.CDLL(ctypes.util.find_library('lz4'))
lib.LZ4_decompress_safe.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_int]
lib.LZ4_decompress_safe.restype=ctypes.c_int
def dec(b,n,flags):
    if flags&63==0:assert len(b)==n;return b
    if flags&63==1:
        p,d=struct.unpack('<BI',b[:5]);lc=p%9;p//=9;lp=p%5;pb=p//5
        c=lzma.LZMADecompressor(format=lzma.FORMAT_RAW,filters=[{'id':lzma.FILTER_LZMA1,'dict_size':d,'lc':lc,'lp':lp,'pb':pb}])
        data=c.decompress(b[5:],max_length=n+1);assert len(data)==n
        return data
    assert flags&63 in (2,3),flags
    out=ctypes.create_string_buffer(n)
    size=lib.LZ4_decompress_safe(b,out,len(b),n)
    assert size==n,(size,n)
    return out.raw

base=Path(__file__).parent
out=base/'static-bundle-extracted';out.mkdir(exist_ok=True)
raw=(base/'scripts64.assembled.bin').read_bytes()
assert raw[:10]==b'\0'*10
r=Reader(raw[10:])
sig=r.z();ver=r.num('I');player=r.z();engine=r.z();size,cs,us,flags=r.fmt('QIII')
assert sig=='UnityFS' and size==len(r.b)
print('BUNDLE',sig,ver,player,engine,size,cs,us,hex(flags),flush=True)
r.align(16)
bi=Reader(dec(r.take(cs),us,flags))
bi.take(16);n=bi.num('I');blocks=[]
for _ in range(n):blocks.append(bi.fmt('IIH'))
nf=bi.num('I');files=[]
for _ in range(nf):files.append((*bi.fmt('QQI'),bi.z()))
assert bi.p==len(bi.b)
print('BLOCKS',blocks,'FILES',files,flush=True)
if flags&512:r.align(16)
all_data=b''.join(dec(r.take(c),u,f) for u,c,f in blocks)
assert r.p==len(r.b),(r.p,len(r.b))
for off,n,f,name in files:
    assert '/' not in name and '\\' not in name
    p=out/name;p.write_bytes(all_data[off:off+n]);print('EXTRACTED',p,n,flush=True)
