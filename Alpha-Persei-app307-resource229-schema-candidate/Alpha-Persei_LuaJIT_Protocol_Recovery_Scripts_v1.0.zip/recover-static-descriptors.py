"""Restricted static constant propagation over descriptor declarations.

No Lua VM, loaded bytecode, dynamic imports from inputs, foreign calls, branch
following, or game function execution. CALL sites become symbolic constructor
nodes only for the explicit protobuf declaration vocabulary below.
"""
from pathlib import Path
import runpy,json,collections,hashlib
# This only imports our own bounds-checked bytecode-format reader.
api=runpy.run_path(str(Path(__file__).with_name('parse-static-luajit.py')))
parse,OPS=api['parse'],api['OPS']
class Sym(tuple):
 def __new__(cls,*parts):return super().__new__(cls,parts)
class Node(dict):
 def __init__(self,kind,origin):super().__init__();self.kind=kind;self.origin=origin

def declarations(path):
 ps=parse(path);assert len(ps)==1
 p=ps[0];reg={};glob={};descriptors=[];fields=[];module=path.name.removesuffix('.lua.bytes')
 calls=collections.Counter()
 def get(base,key):
  if isinstance(base,Sym):return Sym(*base,key)
  assert isinstance(base,dict),(module,pc,'non-table get',base,key)
  assert key in base,(module,pc,'unknown table key',key)
  return base[key]
 for pc,v in enumerate(p['ins']):
  op=OPS[v&255];a=(v>>8)&255;b=v>>24;c=(v>>16)&255;d=v>>16;k=p['k']
  if op=='KSTR':reg[a]=k[d]
  elif op=='KSHORT':reg[a]=d if d<32768 else d-65536
  elif op=='KPRI':reg[a]=[None,False,True][d]
  elif op=='TNEW':reg[a]=Node('table',(module,pc))
  elif op=='GGET':reg[a]=glob.get(k[d],Sym('global',k[d]))
  elif op=='GSET':glob[k[d]]=reg[a]
  elif op=='TGETS':reg[a]=get(reg[b],k[c])
  elif op=='TGETV':reg[a]=get(reg[b],reg[c])
  elif op in ('TSETS','TSETV','TSETB'):
   key=k[c] if op=='TSETS' else reg[c] if op=='TSETV' else c
   obj=reg[b];assert isinstance(obj,Node),(module,pc,'non-node assignment',obj)
   obj[key]=reg[a]
  elif op=='CALL':
   target=reg[a];args=[reg[a+2+j] for j in range(c-1)];calls[str(target)]+=1
   assert isinstance(target,Sym),(module,pc,target)
   if target==Sym('global','require'):
    assert len(args)==1 and isinstance(args[0],str)
    result=Sym('module',args[0])
   elif target==Sym('global','module'):
    assert args[0]==module and args[1]==Sym('global','package','seeall')
    result=None
   elif target in (Sym('module','protobuf','Descriptor'),Sym('module','protobuf','FieldDescriptor')):
    assert not args
    result=Node(target[-1],(module,pc));(descriptors if target[-1]=='Descriptor' else fields).append(result)
   elif target==Sym('module','protobuf','Message'):
    assert len(args)==1 and isinstance(args[0],Node) and args[0].kind=='Descriptor'
    result=Sym('message',module,args[0]['name'])
   else:raise ValueError((module,pc,'unrecognized call declaration',target,args))
   assert b in (1,2),(module,pc,'unexpected results',b)
   if b==2:reg[a]=result
  elif op=='RET1':assert reg[a]==Sym('global',module)
  else:raise ValueError((module,pc,'non-declarative opcode',op))
 assert len(descriptors)==sum(x.kind=='Descriptor' for x in glob.values() if isinstance(x,Node))
 return {'module':module,'descriptors':descriptors,'fields':fields,'globals':glob,'calls':dict(calls),'bytecode_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def main():
 base=Path(__file__).parent
 paths=sorted((base/'static-bundle-extracted/textassets/assets/luabuilds/luajit2.0/x64/protocol').glob('*.bytes'))
 modules={p.name.removesuffix('.lua.bytes'):declarations(p) for p in paths}
 names=collections.defaultdict(list);allfields=[];messages=[];rawmessages=[];fieldmeta=collections.Counter();msgmeta=collections.Counter();source=[]
 for mn,mod in modules.items():
  for msg in mod['descriptors']:names[msg['name']].append((mn,msg))
 def schema_name(obj):
  return obj['name'] if len(names[obj['name']])==1 else obj.origin[0]+'.'+obj['name']
 TYPES={1:'double',2:'float',3:'int64',4:'uint64',5:'int32',6:'fixed64',7:'fixed32',8:'bool',9:'string',10:'group',11:'message',12:'bytes',13:'uint32',14:'enum',15:'sfixed32',16:'sfixed64',17:'sint32',18:'sint64'}
 LABELS={1:'optional',2:'required',3:'repeated'}
 def refobject(value):
  if isinstance(value,Node):assert value.kind=='Descriptor';return value
  assert isinstance(value,Sym),value
  assert value[0]=='module' and value[1].startswith('protocol/') and len(value)==3,value
  mod=modules[value[1].split('/')[-1]]
  obj=mod['globals'][value[2]];assert isinstance(obj,Node) and obj.kind=='Descriptor',(value,obj)
  return obj
 for modname,mod in modules.items():
  for msg in mod['descriptors']:
   msgmeta.update(msg.keys());name=msg['name']
   fld=msg['fields'];assert isinstance(fld,Node)
   assert list(sorted(fld))==list(range(1,len(fld)+1)),(name,list(fld))
   fs=[];rawfs=[]
   for idx,field in sorted(fld.items()):
    assert isinstance(field,Node) and field.kind=='FieldDescriptor'
    fieldmeta.update(field.keys());allfields.append(id(field))
    f={x:field[x] for x in ('name','number','type','label')};f['type']=TYPES[f['type']];f['label']=LABELS[f['label']]
    assert field['index']==idx-1,(name,idx,field)
    rawf=dict(f)
    if f['type']=='message':
     obj=refobject(field['message_type']);f['ref']=schema_name(obj);rawf['ref']=obj['name'];rawf['ref_module']=obj.origin[0]
    else:f['ref']=None;rawf['ref']=None
    rawfs.append(rawf)
    if f['type']=='enum':raise ValueError(('enum needs analysis',name,f))
    fs.append(f)
   assert len({f['number'] for f in fs})==len(fs)
   assert len({f['name'] for f in fs})==len(fs)
   messages.append({'name':schema_name(msg),'fields':fs})
   rawmessages.append({'name':name,'source_module':modname,'full_name':msg['full_name'],'fields':rawfs})
  source.append({'module':modname,'messages':len(mod['descriptors']),'fields':len(mod['fields']),'bytecode_sha256':mod['bytecode_sha256']})
 assert len(allfields)==len(set(allfields))
 assert len(allfields)==sum(len(m['fields']) for m in modules.values())
 canonical_names={m['name'] for m in messages};assert len(canonical_names)==len(messages)
 unresolved=[(m['name'],f) for m in messages for f in m['fields'] if f.get('ref') and f['ref'] not in canonical_names]
 assert not unresolved,unresolved
 messages.sort(key=lambda m:m['name'])
 deliver=base/'recovered-protocol';deliver.mkdir(exist_ok=True)
 payload={'messages':messages}
 (deliver/'raw-descriptors-with-provenance.json').write_text(json.dumps({'messages':rawmessages},ensure_ascii=False,indent=2)+'\n')
 (deliver/'lua_proto_messages.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
 summary={'bundle_md5':'86add1e9d150efa2464ec96f0579a0b9','protocol_files':len(paths),'messages':len(messages),'fields':len(allfields),'unresolved_references':len(unresolved),'unique_original_names':len(names),'duplicate_original_name_groups':sum(len(v)>1 for v in names.values()),'duplicate_output_names':0,'qualified_names':[m['name'] for m in messages if '.' in m['name']],'types':dict(collections.Counter(f['type'] for m in messages for f in m['fields'])),'labels':dict(collections.Counter(f['label'] for m in messages for f in m['fields'])),'message_metadata_keys':dict(msgmeta),'field_metadata_keys':dict(fieldmeta),'source_modules':source}
 (deliver/'extraction-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps({k:v for k,v in summary.items() if k!='source_modules'},indent=2))
 for name in ('sc_10039','sc_10043','sc_10051','sc_10201','cs_10042'):
  print(json.dumps(next(m for m in messages if m['name']==name),indent=2))
if __name__=='__main__':main()
