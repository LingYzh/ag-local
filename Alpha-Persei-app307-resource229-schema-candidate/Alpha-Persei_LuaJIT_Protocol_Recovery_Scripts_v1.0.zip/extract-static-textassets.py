from pathlib import Path
import struct,json,hashlib,collections
class R:
 def __init__(self,b,e='>'):self.b,self.p,self.e=b,0,e
 def take(self,n):
  assert 0<=n<=len(self.b)-self.p,(self.p,n,len(self.b))
  v=self.b[self.p:self.p+n];self.p+=n;return v
 def num(self,f):return self.fmt(f)[0]
 def fmt(self,f):return struct.unpack(self.e+f,self.take(struct.calcsize(self.e+f)))
 def z(self):
  q=self.b.index(0,self.p);v=self.take(q-self.p);self.take(1);return v.decode()
 def align(self,n=4):self.p=(self.p+n-1)//n*n
 def string(self):
  v=self.take(self.num('i'));self.align();return v.decode()
base=Path(__file__).parent
out=base/'static-bundle-extracted'
r=R((out/'CAB-win64').read_bytes())
ms,fs,ver,do=r.fmt('4I');endian=r.num('B');r.take(3)
assert ver==22
ms,fs,do,unknown=r.fmt('IQQQ');r.e='>' if endian else '<'
assert fs==len(r.b)
engine=r.z();target=r.num('i');tt=r.num('B');nt=r.num('i')
print('SERIALIZED',ms,fs,ver,do,engine,target,'typetree',tt,'types',nt,flush=True)
types=[]
for i in range(nt):
 cid=r.num('i');stripped=r.num('B');si=r.num('h')
 if cid==114:r.take(16)
 th=r.take(16)
 if tt:
  nn,ns=r.fmt('2i');r.take(nn*32);sb=r.take(ns);deps=r.num('i');r.take(deps*4)
 types.append(cid)
print('TYPES',types,'pos',r.p,flush=True)
no=r.num('i');objects=[]
for i in range(no):
 r.align();pid,off,size,tid=r.fmt('qQIi')
 objects.append({'id':pid,'off':off+do,'size':size,'class':types[tid]})
print('OBJECTS',no,dict(collections.Counter(x['class'] for x in objects)),flush=True)
paths={}
for ob in objects:
 if ob['class']!=142:continue
 a=R(r.b[ob['off']:ob['off']+ob['size']],r.e)
 name=a.string();preloads=a.num('i');a.take(preloads*12)
 containers=a.num('i')
 print('BUNDLE OBJECT',name,preloads,containers,flush=True)
 for i in range(containers):
  key=a.string();preidx,presz,fid,pid=a.fmt('iiiq');paths[pid]=key
(out/'asset-paths.json').write_text(json.dumps(paths,indent=2))
manifest=[];counts=collections.Counter()
for ob in objects:
 if ob['class']!=49:continue
 a=R(r.b[ob['off']:ob['off']+ob['size']],r.e)
 name=a.string();payload=a.take(a.num('i'));a.align()
 assert a.p==len(a.b),(name,a.p,len(a.b))
 path=paths.get(ob['id'],str(ob['id'])+'_'+name)
 pp=Path(path);assert not pp.is_absolute() and '..' not in pp.parts
 typ='luajit' if payload.startswith(b'\x1bLJ') else 'lua' if payload.startswith(b'\x1bLua') else 'other'
 counts[typ]+=1
 dest=out/'textassets'/pp;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(payload)
 manifest.append({'id':ob['id'],'name':name,'path':path,'bytes':len(payload),'type':typ,'sha256':hashlib.sha256(payload).hexdigest()})
(out/'textassets-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('TEXTASSETS',len(manifest),dict(counts),flush=True)
print('PROTOCOL',json.dumps([x for x in manifest if '/protocol/' in x['path']],indent=2),flush=True)
