"""Independent data-only checks. Never imports or runs downloaded/game code."""
from pathlib import Path
import collections, hashlib, json, re, struct

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'schema-audit'
PROTO = ROOT / 'static-bundle-extracted/textassets/assets/luabuilds/luajit2.0/x64/protocol'
RAW = json.loads((ROOT/'recovered-protocol/raw-descriptors-with-provenance.json').read_text())['messages']
SCHEMA = json.loads((ROOT/'recovered-protocol/lua_proto_messages.json').read_text())['messages']
official_ops = re.findall(r'^\s*_\(([A-Z0-9]+),', (OUT/'source/src/lj_bc.h').read_text(), re.M)
descriptor_source = (OUT/'source/src/google/protobuf/descriptor.proto').read_text()
TYPES = {int(n): v.lower() for v,n in re.findall(r'TYPE_(\w+)\s*=\s*(\d+)', descriptor_source)}
LABELS = {int(n): v.lower() for v,n in re.findall(r'LABEL_(\w+)\s*=\s*(\d+)', descriptor_source)}
opcounts = collections.Counter()
callcounts = collections.Counter()
all_nodes = []
modules = {}
numeric_constants = 0

class Reader:
    def __init__(self, data): self.data,self.offset=data,0
    def bytes(self,n):
        assert n >= 0 and self.offset+n <= len(self.data)
        value=self.data[self.offset:self.offset+n]; self.offset+=n; return value
    def uleb(self):
        result=0
        for shift in range(0,35,7):
            n=self.bytes(1)[0]; result |= (n & 127) << shift
            if not n & 128: return result
        raise AssertionError('invalid ULEB128')

def read_chunk(path):
    global numeric_constants
    r=Reader(path.read_bytes())
    assert r.bytes(4)==b'\x1bLJ\x02'
    assert r.uleb()==10 # STRIP + FR2, little endian, no FFI
    size=r.uleb(); end=r.offset+size
    flags,params,frame,uv=r.bytes(4)
    ngc,nn,ni=r.uleb(),r.uleb(),r.uleb()
    assert params==0 and uv==0
    ins=[int.from_bytes(r.bytes(4),'little') for _ in range(ni)]
    const=[]
    for _ in range(ngc):
        typ=r.uleb()
        assert typ>=5 # protocol files have only string GC constants
        const.insert(0,r.bytes(typ-5).decode('utf-8'))
    numeric_constants+=nn
    # Unused numeric constants are still consumed and their bounds checked.
    for _ in range(nn):
        lo=r.uleb()
        if lo & 1: r.uleb()
    assert r.offset==end and r.uleb()==0 and r.offset==len(r.data)
    return frame,ins,const

def symbol(*parts): return tuple(parts)

def node(kind,module,pc):
    value={'@kind':kind,'@module':module,'@pc':pc}
    all_nodes.append(value)
    return value

for path in sorted(PROTO.glob('*.bytes')):
    module=path.name.removesuffix('.lua.bytes')
    frame,ins,k=read_chunk(path)
    g={}; r={}
    modules[module]=g
    for pc,word in enumerate(ins):
        op=official_ops[word&255]; a=(word>>8)&255; b=word>>24; c=(word>>16)&255; d=word>>16
        opcounts[op]+=1
        assert a<frame or op=='RET1'
        if op=='GGET': r[a]=g.get(k[d],symbol('global',k[d]))
        elif op=='GSET': g[k[d]]=r[a]
        elif op=='KSTR': r[a]=k[d]
        elif op=='KSHORT': r[a]=struct.unpack('<h',d.to_bytes(2,'little'))[0]
        elif op=='KPRI': r[a]=(None,False,True)[d]
        elif op=='TNEW': r[a]=node('table',module,pc)
        elif op in ('TGETS','TGETV'):
            key=k[c] if op=='TGETS' else r[c]; base=r[b]
            r[a]=base+(key,) if isinstance(base,tuple) else base[key]
        elif op in ('TSETS','TSETV','TSETB'):
            key=k[c] if op=='TSETS' else r[c] if op=='TSETV' else c
            assert isinstance(r[b],dict)
            r[b][key]=r[a]
        elif op=='CALL':
            target=r[a]; args=[r[n] for n in range(a+2,a+c+1)]
            assert isinstance(target,tuple) and b in (1,2)
            callcounts['/'.join(map(str,target))]+=1
            if target==('global','require'):
                assert len(args)==1; result=symbol('module',args[0])
            elif target==('global','module'):
                assert args==[module,('global','package','seeall')]; result=None
            elif target in [('module','protobuf','Descriptor'),('module','protobuf','FieldDescriptor')]:
                assert not args; result=node(target[-1],module,pc)
            elif target==('module','protobuf','Message'):
                assert len(args)==1 and args[0]['@kind']=='Descriptor'
                result=symbol('message',module,args[0]['name'])
            else: raise AssertionError(('unexpected call',target))
            if b==2: r[a]=result
        elif op=='RET1':
            assert pc==len(ins)-1 and r[a]==('global',module)
        else: raise AssertionError(('unsupported opcode',op))

def ref_target(ref):
    if isinstance(ref,dict): return ref
    assert ref[0]=='module' and ref[1].startswith('protocol/') and len(ref)==3
    return modules[ref[1].split('/')[-1]][ref[2]]

independent=[]
for n in all_nodes:
    if n['@kind']!='Descriptor': continue
    fields=[]
    for index,f in sorted((key,value) for key,value in n['fields'].items() if isinstance(key,int)):
        assert f['@kind']=='FieldDescriptor' and f['index']==index-1
        value={'name':f['name'],'number':f['number'],'type':TYPES[f['type']],'label':LABELS[f['label']],'ref':None}
        assert 1<=f['number']<=536870911 and not 19000<=f['number']<=19999
        if value['type']=='message':
            target=ref_target(f['message_type']); assert target['@kind']=='Descriptor'
            value.update(ref=target['name'],ref_module=target['@module'])
        fields.append(value)
    independent.append({'name':n['name'],'source_module':n['@module'],'full_name':n['full_name'],'fields':fields})
key=lambda m:(m['source_module'],m['name'])
assert sorted(independent,key=key)==sorted(RAW,key=key)

normalize=lambda name:name.strip().lstrip('.').lower()
names=[normalize(m['name']) for m in SCHEMA]
assert len(set(names))==len(names)
index={normalize(m['name']):m for m in SCHEMA}
refs=[normalize(f['ref']) for m in SCHEMA for f in m['fields'] if f['type']=='message']
assert all(name in index for name in refs)
rawcounts=collections.Counter(m['name'] for m in RAW)
rawkeys={key(m):m for m in RAW}
for m in independent:
    expected_name=m['name'] if rawcounts[m['name']]==1 else m['source_module']+'.'+m['name']
    target=index[normalize(expected_name)]
    assert len(target['fields'])==len(m['fields'])
    for rawf,f in zip(m['fields'],target['fields']):
        for attr in ('name','number','type','label'): assert rawf[attr]==f[attr]
        ref=rawf['ref']
        if ref and rawcounts[ref]>1: ref=rawf['ref_module']+'.'+ref
        assert f['ref']==ref

canonical={normalize(m['name'] if rawcounts[m['name']]==1 else m['source_module']+'.'+m['name']) for m in independent}
extra_names=set(index)-canonical
assert extra_names=={'crickets_round_score_net_rec'}
assert index['crickets_round_score_net_rec']['fields']==index['p58_pb.crickets_round_score_net_rec']['fields']

# Independently compare representative assignments against the pinned public file.
public_root=ROOT/'public-protocol/protocol'
public_bytes=(public_root/'p10_pb.lua').read_bytes()
public_blob=hashlib.sha1(b'blob '+str(len(public_bytes)).encode()+b'\0'+public_bytes).hexdigest()
# Local materialization appended one final newline; verify the exact upstream
# blob after removing that known formatting-only addition, without editing it.
public_materialization_extra_newline=False
if public_blob!='8d202c5bd546a67630a39ac3c1980400610e49e2':
    assert public_bytes.endswith(b'\n')
    public_bytes=public_bytes[:-1]
    public_materialization_extra_newline=True
    public_blob=hashlib.sha1(b'blob '+str(len(public_bytes)).encode()+b'\0'+public_bytes).hexdigest()
assert public_blob=='8d202c5bd546a67630a39ac3c1980400610e49e2'
public_text=public_bytes.decode('utf-8-sig')
public_fields_checked=0
for packet in ('sc_10039','sc_10043','sc_10051'):
    const=packet.upper()
    field_block=re.search(r'^'+const+r'\.fields = \{(.*?)\}',public_text,re.M|re.S).group(1)
    vars=[v.strip() for v in field_block.split(',') if v.strip()]
    assert len(vars)==len(index[packet]['fields'])
    for var,f in zip(vars,index[packet]['fields']):
        assignments={attribute:expression for attribute,expression in re.findall(r'^'+re.escape(var)+r'\.(\w+) = (.+)$',public_text,re.M)}
        assert json.loads(assignments['name'])==f['name']
        assert int(assignments['number'])==f['number']
        assert TYPES[int(assignments['type'])]==f['type']
        assert LABELS[int(assignments['label'])]==f['label']
        if f['type']=='message':
            expression=assignments['message_type']
            match=re.fullmatch(r'require\("protocol/(\w+)"\)\.(\w+)',expression)
            refmodule,refvar=match.groups() if match else ('p10_pb',expression)
            source=(public_root/(refmodule+'.lua')).read_text(encoding='utf-8-sig')
            refname=json.loads(re.search(r'^'+re.escape(refvar)+r'\.name = (.+)$',source,re.M).group(1))
            assert f['ref']==refname
        public_fields_checked+=1

report={
    'method':'Independent standard-library data parser using official LuaJIT opcode table and official protobuf type/label enums; no downloaded code executed',
    'bundle_md5':hashlib.md5((ROOT/'scripts64.assembled.bin').read_bytes()).hexdigest(),
    'protocol_files':len(modules),'descriptors_verified':len(independent),
    'fields_verified':sum(len(m['fields']) for m in independent),
    'raw_descriptor_differences':0,'schema_mapping_differences':0,
    'normalized_name_collisions':len(names)-len(set(names)),
    'message_refs_verified':len(refs),'unresolved_refs':0,
    'qualified_names':sum('.' in m['name'] for m in SCHEMA),
    'final_candidate_messages':len(SCHEMA),
    'final_candidate_fields':sum(len(m['fields']) for m in SCHEMA),
    'compatibility_aliases_verified':{'crickets_round_score_net_rec':'p58_pb.crickets_round_score_net_rec'},
    'wire_packet_names_modified':[m['name'] for m in RAW if re.fullmatch(r'[cs]s_\d+',m['name']) and m['name'] not in index],
    'opcode_counts':dict(opcounts),'symbolic_call_counts':dict(callcounts),
    'numeric_constants':numeric_constants,
    'schema_sha256':hashlib.sha256((ROOT/'recovered-protocol/lua_proto_messages.json').read_bytes()).hexdigest(),
    'public_representative_field_checks':public_fields_checked,
    'public_p10_git_blob_sha':public_blob,
    'public_materialization_extra_newline':public_materialization_extra_newline,
    'public_p10_url':'https://github.com/PackageInstaller/DataTable/blob/83b4bf07a62a73b05e74c22f1c47e59ae0983ae2/MasterData/Lua/x64/protocol/p10_pb.lua',
    'representative_messages':[index[name] for name in ['sc_10039','sc_10043','sc_10051']],
}
(OUT/'independent-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='representative_messages'},indent=2))
