# Alpha Persei 历史协议恢复脚本

配套文档：`Alpha-Persei_LuaJIT_Protocol_Recovery_Method_v1.0.md`。

这是 app 307 / resource 229 样本的分析材料，不是游戏补丁或通用解包工具。请先阅读配套文档中的复现步骤和安全限制，再在独立空目录中处理输入副本。不要把这些脚本放进运行中的服务器或客户端目录。

## 文件内容

- 六个实际分析脚本，职责见配套文档
- `script-manifest.json`：历史脚本与附件脚本的 SHA-256，以及两处路径调整说明
- `reference-inputs.json`：原审计参考文本的来源、长度和 SHA-256
- `baseline/`：历史静态报告和公开源码 Git blob 清单，用于核对；不是这次重跑自动生成的结果

包内不包含游戏资源、字节码、游戏公开 Lua 源码、官方参考源码、Python、liblz4 或任何安装程序。必须另外提供经过身份校验的原输入；可选的外部交叉审计还需要相应源码文本。源码只按数据读取，不需要运行它们。

## 与原脚本的差异

`extract-static-unity.py`、`extract-static-textassets.py`、`parse-static-luajit.py`、`recover-static-descriptors.py` 与历史版本逐字节一致。

`compare-public-descriptors.py` 中的 `pub` 和 `schema-audit/independent_audit.py` 中的 `public_root` 改为工作目录中的 `public-protocol/protocol`。仅修改了这两个输入路径，解析、验证和输出逻辑不变。

## 复现顺序

配套文档第 9 节给出了输入拼接、依赖检查、真实脚本命令和兼容别名代码。请按顺序执行，不要自行寻找不存在的 `--input` 或 `--output` 参数。

1. 核对历史输入：35,790,934 字节，MD5 为 `86add1e9d150efa2464ec96f0579a0b9`
2. 依次运行 UnityFS 提取、TextAsset 提取、LuaJIT 读取、描述恢复四个脚本
3. 基础输出应为 3,061 条定义、6,889 个字段
4. 可选地准备固定公开 Lua 文本，执行交叉比较
5. 依照文档中的数据变换代码，添加唯一已核实的兼容别名
6. 最终候选应为 3,062 个消息键、6,892 个字段，SHA-256 为 `b9101c965ed4f75317aa9c0199e17e5a7d2c3e0c0e23b982217a960b1a6ee79f`
7. 准备官方参考文本后，可运行独立审计脚本

拼接和别名操作原先是临时 Python 命令，没有保存在独立历史脚本中；配套文档提供了可核验的整理版命令。不要误以为 `recover-static-descriptors.py` 会自动添加别名。重跑它会重新写出基础 3,061 条版本。

## 运行边界

- 已验证环境为 Linux、Python 3.12 和已有的系统 liblz4；未验证原生 Windows 直接运行
- 不要使用 `python -O`，不要设置 `PYTHONOPTIMIZE`；原脚本依赖断言检查
- 未覆盖任意 UnityFS 标志、尾部块表、所有 SerializedFile 版本或未知 LuaJIT 语义
- 没有通用的内存和解压预算管理，也没有完整恶意输入加固
- 不要把新的资源直接交给固定样本脚本后就相信报告中的历史版本和摘要常量
- 出现未知格式、调用、指令或引用，应停止分析，不应跳过错误

## 历史报告怎样阅读

`baseline/extraction-validation.json` 在基础提取之后补充了输入身份、最终兼容层和摘要，因此字段比核心脚本重新生成的基础报告更多。

`baseline/public-source-inventory.json` 的 `version_match: Unverified` 是最初采集清单的状态。后续逐项对比确认 3,061 个源描述一致，结论见 `baseline/public-comparison.json`；不能把这理解为整个客户端和公开仓库的完整版本一致。

独立静态报告中的 `runtime_test_performed: false` 是原审计范围的真实记录。后续用户进入主界面的反馈与静态报告分开记录，不是全游戏验证通过。

## 外部数据的准备

公开协议文本：从 `baseline/public-source-inventory.json` 中的固定提交链接取得 92 个文件，保持各自文件名，放到 `public-protocol/protocol/`。不要运行该仓库代码。

独立审计还需要 `schema-audit/source/src/lj_bc.h` 和 `schema-audit/source/src/google/protobuf/descriptor.proto`。后者原快照只是官方枚举相关片段。原审计参考分支未固定 commit；`reference-inputs.json` 的摘要只能验证所保存快照，不能让今日浮动分支自动变成相同文件。使用新参考文本时应重新审核 opcode 与类型映射。仅下载文件不等于已完成复核。

## 本文整理时的复核

文件 `reproduction-check.json` 记录对附件脚本和文档命令进行的静态分析重放范围与结果。它与历史 `baseline/` 报告分开保存，不代表运行过游戏或服务器。
