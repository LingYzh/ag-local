"""Read LuaJIT bytecode as data; never load it in Lua or execute its functions."""
from pathlib import Path
import struct,json,collections,sys
OPS='ISLT ISGE ISLE ISGT ISEQV ISNEV ISEQS ISNES ISEQN ISNEN ISEQP ISNEP ISTC ISFC IST ISF ISTYPE ISNUM MOV NOT UNM LEN ADDVN SUBVN MULVN DIVVN MODVN ADDNV SUBNV MULNV DIVNV MODNV ADDVV SUBVV MULVV DIVVV MODVV POW CAT KSTR KCDATA KSHORT KNUM KPRI KNIL UGET USETV USETS USETN USETP UCLO FNEW TNEW TDUP GGET GSET TGETV TGETS TGETB TGETR TSETV TSETS TSETB TSETM TSETR CALLM CALL CALLMT CALLT ITERC ITERN VARG ISNEXT RETM RET RET0 RET1 FORI JFORI FORL IFORL JFORL ITERL IITERL JITERL LOOP ILOOP JLOOP JMP'.split()
class R:
 def __init__(self,b):self.b=b;self.p=0
 def take(self,n):
  assert 0<=n<=len(self.b)-self.p,(self.p,n,len(self.b))
  x=self.b[self.p:self.p+n];self.p+=n;return x
 def u(self):
  x=0;s=0
  for _ in range(6):
   c=self.take(1)[0];x|=(c&127)<<s;s+=7
   if c<128:return x
  raise ValueError('long ULEB')
 def n(self):return struct.unpack('<d',struct.pack('<II',self.u(),self.u()))[0]
 def tk(self):
  t=self.u()
  if t>=5:return self.take(t-5).decode('utf8')
  if t==0:return None
  if t==1:return False
  if t==2:return True
  if t==3:
   n=self.u();return n if n<2**31 else n-2**32
  if t==4:return self.n()
  raise ValueError(t)
 def tab(self):
  na,nh=self.u(),self.u();out={i:self.tk() for i in range(na)}
  for _ in range(nh):key=self.tk();out[key]=self.tk()
  return out

def parse(path):
 r=R(Path(path).read_bytes());assert r.take(4)==b'\x1bLJ\2'
 flags=r.u();assert flags==10,flags
 stack=[];protos=[]
 while True:
  n=r.u()
  if not n:break
  end=r.p+n
  pf,params,frame,uv=r.take(4);kgc,kn,nbc=r.u(),r.u(),r.u()
  ins=list(struct.unpack('<'+str(nbc)+'I',r.take(nbc*4)));up=r.take(uv*2)
  k=[]
  for _ in range(kgc):
   t=r.u()
   if t>=5:x=r.take(t-5).decode('utf8')
   elif t==1:x=r.tab()
   elif t==0:x={'child':stack.pop()}
   else:raise ValueError(('unexpected constant type',t))
   k.append(x)
  nums=[]
  for _ in range(kn):
   u=r.u();lo=u>>1
   if u&1:nums.append(struct.unpack('<d',struct.pack('<II',lo,r.u()))[0])
   else:nums.append(lo if lo<2**31 else lo-2**32)
  assert r.p==end,(path,r.p,end)
  p={'flags':pf,'params':params,'frame':frame,'uv':uv,'ins':ins,'k':k[::-1],'nums':nums};stack.append(p);protos.append(p)
 assert r.p==len(r.b)
 return protos

def dis(p):
 out=[]
 for i,v in enumerate(p['ins']):
  op,a,c,b=v&255,(v>>8)&255,(v>>16)&255,v>>24;d=v>>16
  name=OPS[op] if op<len(OPS) else str(op)
  item={'pc':i,'op':name,'a':a,'b':b,'c':c,'d':d}
  if name in ['KSTR','GGET','GSET']:item['constant']=p['k'][d]
  if name in ['TGETS','TSETS']:item['constant']=p['k'][c]
  out.append(item)
 return out
if __name__=='__main__':
 paths=sorted(Path('static-bundle-extracted/textassets/assets/luabuilds/luajit2.0/x64/protocol').glob('*.bytes'))
 counts=collections.Counter();numpro=collections.Counter()
 for path in paths:
  ps=parse(path);numpro[len(ps)]+=1
  for p in ps:counts.update(OPS[v&255] if v&255<len(OPS) else str(v&255) for v in p['ins'])
  if path.name=='p10_pb.lua.bytes':
   Path('p10-static-disassembly.json').write_text(json.dumps({'constants':ps[-1]['k'],'nums':ps[-1]['nums'],'instructions':dis(ps[-1])},ensure_ascii=False,indent=2))
 print('FILES',len(paths),'PROTOTYPES',numpro,'OPS',counts)
