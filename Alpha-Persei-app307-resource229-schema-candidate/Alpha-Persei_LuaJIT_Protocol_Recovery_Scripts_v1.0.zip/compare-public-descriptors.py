"""Read textual Lua assignment literals only. No Lua evaluation."""
from pathlib import Path
import json,re,collections,hashlib
base=Path(__file__).parent
pub=base/'public-protocol/protocol'
raw=json.loads((base/'recovered-protocol/raw-descriptors-with-provenance.json').read_text())['messages']
actual={(m['source_module'],m['name']):m for m in raw}
TYPES={1:'double',2:'float',3:'int64',4:'uint64',5:'int32',6:'fixed64',7:'fixed32',8:'bool',9:'string',10:'group',11:'message',12:'bytes',13:'uint32',14:'enum',15:'sfixed32',16:'sfixed64',17:'sint32',18:'sint64'}
LABELS={1:'optional',2:'required',3:'repeated'}
parsed={}
for p in sorted(pub.glob('*.lua')):
 s=p.read_text(encoding='utf-8-sig');mod=p.stem
 aliases=dict(re.findall(r'(?:local )?(\w+) = require\("protocol/(\w+)"\)',s))
 ds={v:{} for v in re.findall(r'^([A-Z_0-9]+) = protobuf.Descriptor\(\)$',s,re.M)}
 fs={v:{} for v in re.findall(r'^([\w.]+) = protobuf.FieldDescriptor\(\)$',s,re.M)}
 for lhs,attr,expr in re.findall(r'^([\w.]+)\.(name|full_name|number|type|label|message_type) = (.+)$',s,re.M):
  target=ds.get(lhs,fs.get(lhs));assert target is not None,(p,lhs)
  if attr=='message_type':target[attr]=expr
  else:target[attr]=json.loads(expr)
 for lhs,block in re.findall(r'^([A-Z_0-9]+)\.fields = \{(.*?)\}',s,re.M|re.S):
  ds[lhs]['fields']=[fs[x.strip()] for x in block.split(',') if x.strip()]
 for v,d in ds.items():
  assert set(d)=={'name','full_name','fields'},(p,v,set(d))
  for f in d['fields']:
   assert set(f)>={'name','full_name','number','type','label'},(p,v,f)
   f['type']=TYPES[f['type']];f['label']=LABELS[f['label']]
   if f['type']=='message':
    expr=f.pop('message_type');m=re.fullmatch(r'require\("protocol/(\w+)"\)\.([A-Z_0-9]+)',expr)
    if m:refmod,refvar=m.groups()
    elif '.' in expr:
     alias,refvar=expr.split('.');refmod=aliases.get(alias,alias)
    else:refmod,refvar=mod,expr
    f['ref_var']=refvar;f['ref_module']=refmod
  parsed[(mod,v)]=d
source={}
for (mod,v),d in parsed.items():
 fields=[]
 for f in d['fields']:
  ff={x:f[x] for x in ['name','number','type','label']};ff['ref']=None
  if f['type']=='message':ff['ref']=parsed[(f['ref_module'],f['ref_var'])]['name'];ff['ref_module']=f['ref_module']
  fields.append(ff)
 m={'name':d['name'],'full_name':d['full_name'],'source_module':mod,'fields':fields}
 source[(mod,d['name'])]=m
same=[];changed=[]
for key in actual.keys()&source.keys():
 if actual[key]==source[key]:same.append(key)
 else:changed.append({'module':key[0],'name':key[1],'actual':actual[key],'public':source[key]})
report={'public_commit':'83b4bf07a62a73b05e74c22f1c47e59ae0983ae2','public_source':'https://github.com/PackageInstaller/DataTable/tree/83b4bf07a62a73b05e74c22f1c47e59ae0983ae2/MasterData/Lua/x64/protocol','actual_records':len(actual),'public_records':len(source),'same_records':len(same),'changed_records':len(changed),'actual_only':sorted(actual.keys()-source.keys()),'public_only':sorted(source.keys()-actual.keys()),'differences':sorted(changed,key=lambda m:(m['module'],m['name']))}
(base/'recovered-protocol/public-comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='differences'},indent=2))
if changed:print('FIRST_DIFF',json.dumps(changed[0],indent=2))
